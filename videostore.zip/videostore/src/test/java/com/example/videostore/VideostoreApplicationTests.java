package com.example.videostore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VideostoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
